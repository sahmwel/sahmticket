export declare const supabase: import("@supabase/supabase-js").SupabaseClient<any, "public", "public", any, any>;
